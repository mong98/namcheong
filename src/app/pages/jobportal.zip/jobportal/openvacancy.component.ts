import { Component } from '@angular/core';

import { SmartTableDatepickerComponent, SmartTableDatepickerRenderComponent } from '../../smart-table-datepicker/smart-table-datepicker.component'

@Component({
	selector: 'ngx-openvacancy',
  templateUrl: './openvacancy.component.html',
	styleUrls: ['./openvacancy.component.scss']
})

export class OpenVacancyComponent {
	settings = {
	  delete: {
      confirmDelete: true,
    },
    add: {
			addButtonContent: 'Add',
			//createButtonContent: 'Save', // change 'Create' to 'Save'
      confirmCreate: true,
    },
    edit: {
      confirmSave: true,
    },
		//hideSubHeader: true, // hide the add new fields
		
		columns: {
			id: {
				title: 'ID', 
				filter: false,
				editable: false
			},
			position: {
				title: 'Position',
				filter: false
			},
			end_date: {
				title: 'End Date',
				type: 'custom',
        renderComponent: SmartTableDatepickerRenderComponent,
        //width: '250px',
        filter: false,
        sortDirection: 'desc',
        editor: {
          type: 'custom',
          component: SmartTableDatepickerComponent,
					pickerType: 'calendar',
					timePicker: false,
					format: 'dd-MM-yyyy',
        }
			},
			vessel_type: {
				title: 'Vessel Type',
				filter: false,
				type: 'html',
				editor: { 
				 type: 'list', 
				 config: {
					 selectText: 'Select...',
					 list: [{ value: 'SK75', title: 'SK75' }, { value: 'SK92', title: 'SK92' }, 
									{ value: '<b>SK79</b>', title: 'SK79'}, { value: 'SK901', title: 'SK901' },
									{ value: '<b>SK512</b>', title: 'SK512'}, { value: 'SK606', title: 'SK606' },  
									{ value: '<b>SK715</b>', title: 'SK715'}, { value: 'SK82', title: 'SK82' },
									{ value: '<b>SK317</b>', title: 'SK317'}, { value: 'SK605', title: 'SK605' },  
									{ value: '<b>SK511</b>', title: 'SK511'}, { value: 'SK513', title: 'SK513' },
				 ],
				},
				},
			},
			qualification: {
				title: 'Qualification',
				filter: false
			}
		},
		
		actions: {
      //delete: false,
			add: true,
      position: 'right' // left|right
    },
	};

	data = [
		{
			id: 1,
			position: "Master",
			end_date: "8-11-2020",
			vessel_type: "SK75",
			qualification: "SPM"
		},
		{
			id: 2,
			position: "Chief Engineer",
			end_date: "8-11-2020",
			vessel_type: "SK92",
			qualification: "PMR"
		},
		{
			id: 3,
			position: "2nd Engineer",
			end_date: "8-11-2020",
			vessel_type: "SK79",
			qualification: "PMR"
		},
		{
			id: 4,
			position: "3rd Engineer",
			end_date: "8-11-2020",
			vessel_type: "SK901",
			qualification: "PMR"
		},
		{
			id: 5,
			position: "Chief Officer",
			end_date: "8-11-2020",
			vessel_type: "SK512",
			qualification: "PMR"
		},
		{
			id: 6,
			position: "2nd Officer",
			end_date: "8-11-2020",
			vessel_type: "SK606",
			qualification: "PMR"
		},
		{
			id: 7,
			position: "Electrician",
			end_date: "8-11-2020",
			vessel_type: "SK715",
			qualification: "PMR"
		},
		{
			id: 8,
			position: "ETO",
			end_date: "8-11-2020",
			vessel_type: "SK82",
			qualification: "PMR"
		},
		{
			id: 9,
			position: "Cook",
			end_date: "8-11-2020",
			vessel_type: "SK317",
			qualification: "STPM"
		},
		{
			id: 10,
			position: "Steward/OS",
			end_date: "11-11-2020",
			vessel_type: "SK605",
			qualification: "PMR"
		},
		// ... list of items
		
		{
			id: 11,
			position: "Able Bodied",
			end_date: "8-11-2020",
			vessel_type: "SK511",
			qualification: "PMR"
		},
		{
			id: 12,
			position: "Bosun",
			end_date: "8-11-2020",
			vessel_type: "SK513",
			qualification: "PMR"
		},
		{
			id: 13,
			position: "Crane Operator",
			end_date: "8-11-2020",
			vessel_type: "SK513",
			qualification: "PMR"
		},
		{
			id: 14,
			position: "Medic",
			end_date: "8-11-2020",
			vessel_type: "SK513",
			qualification: "PMR"
		},
		{
			id: 15,
			position: "Oiler",
			end_date: "8-11-2020",
			vessel_type: "SK513",
			qualification: "PMR"
		},
		{
			id: 16,
			position: "Radio Operator",
			end_date: "8-11-2020",
			vessel_type: "SK513",
			qualification: "PMR"
		},
		{
			id: 17,
			position: "Scaffolder",
			end_date: "8-11-2020",
			vessel_type: "SK513",
			qualification: "PMR"
		},
		{
			id: 18,
			position: "Scaffolder Inspector",
			end_date: "8-11-2020",
			vessel_type: "SK513",
			qualification: "PMR"
		},
		{
			id: 19,
			position: "test engineer",
			end_date: "8-11-2020",
			vessel_type: "SK513",
			qualification: "PMR"
		}
	];
	
	onDeleteConfirm(event) {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
    } else {
      event.confirm.reject();
    }
  }

  onSaveConfirm(event) {
    if (window.confirm('Are you sure you want to save?')) {
      event.newData['name'] += ' + added in code';
      event.confirm.resolve(event.newData);
    } else {
      event.confirm.reject();
    }
  }

  onCreateConfirm(event) {
    if (window.confirm('Are you sure you want to create?')) {
      event.newData['name'] += ' + added in code';
      event.confirm.resolve(event.newData);
    } else {
      event.confirm.reject();
    }
  }
}

/*export class DropDownListSmartTableComponent {

}*/