import { NgModule } from '@angular/core';
import { NbCardModule } from '@nebular/theme';

import { Ng2SmartTableModule } from 'ng2-smart-table';
import { NbThemeModule, NbButtonModule, NbLayoutModule } from '@nebular/theme';
import { FormsModule } from '@angular/forms';


import { ThemeModule } from '../../@theme/theme.module';
import { OpenVacancyComponent } from './openvacancy.component';

@NgModule({
  imports: [
    NbCardModule,
    ThemeModule,
		Ng2SmartTableModule,
		NbThemeModule, 
		NbButtonModule,
		NbLayoutModule,
    FormsModule,
    //NbThemeModule.forRoot({name: 'dark'}), // dark theme for all pages
  ],
  declarations: [
    OpenVacancyComponent,
  ],
})
export class OpenVacancyModule { }
