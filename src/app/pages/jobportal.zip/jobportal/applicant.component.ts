import { Component, NgModule } from '@angular/core';
import { NbDatepickerModule } from '@nebular/theme';
import { SmartTableDatepickerComponent, SmartTableDatepickerRenderComponent } from '../../smart-table-datepicker/smart-table-datepicker.component';

@Component({
  selector: 'ngx-applicant',
  templateUrl: './applicant.component.html',
})



export class ApplicantComponent {
  settings = {
    columns: {
      name: {
        title: 'Name',
      },
      relationship: {
        title: 'Relationship',
      },
      occupation: {
        title: 'Occupation',
      },
      contactNumber: {
        title: 'Contact Number',
      },
      dateOfBirth: {
        title: 'Date Of Birth',
      },
      age: {
        title: 'Age',
      },
    },
  };
  data = [];

}
